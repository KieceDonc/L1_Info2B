/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jeumemory;

/**
 *
 * @author Valentin
 */
public class Erreur {
    
    public static final String mustChooseDifficulty = "Vous devez choisir une difficulté avant de saisir un nouveau joueur";
    public static final String playerAlreadyInDataBase = "Le joueur ajouté existe déjà, il n'a donc pas été ajouté";
    public static final String youMustSelectTwoPlayer = "Vous devez sélectionner 2 joueurs pour commencer à jouer";
    public static final String PlayerSelectedFamillyNotInRange = "Un joueur a sélectionné une famille préférée qui n'est pas disponible pour ce niveau de difficulté";
    public static final String OnePlayerAlreadyInTheList = "Un joueur ajouté est déjà présent dans la liste des joueurs. Les joueurs n'ont pas été ajouté";
    
}
